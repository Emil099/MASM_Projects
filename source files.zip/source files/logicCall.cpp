//Program to call "logicalFunc.asm" to show how and,or,xor & not logic works
#include <stdio.h>

extern "C"
{
    void asmFUNC(void);
};

int main()
{
    printf("Calling MASM function\n");
    asmFUNC();
    printf("Returned from MASM function\n");
}