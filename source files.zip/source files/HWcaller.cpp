// MASM & C++ Hybrid "Hello, World!" Caller
#include <stdio.h>

extern "C"
{
    void asmFUNC(void);
};

int main()
{
    printf("Calling MASM function\n");
    asmFUNC();
    printf("Returned from MASM function\n");
}